# Build stages
1. Foundation (done): auth, schema, RLS, landing, dashboard
2. IMEI checker: Luhn, HMAC match, 4 results, history, rate limit
3. Lost report: form, private upload, status tracking
4. GD AI service: FastAPI, OCR, template check, tampering analysis
5. Ownership transfer + recovery + police directory
6. Admin dashboard, analytics, audit logs, API docs, final ZIP
Add new feature ideas to the bottom of this file as they come up.
