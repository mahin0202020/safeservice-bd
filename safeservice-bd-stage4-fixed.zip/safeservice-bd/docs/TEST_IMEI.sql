-- TEST ONLY. Makes one fake "verified" lost report so you can see the red result.
-- 1) Replace YOUR_EMAIL and YOUR_IMEI_HMAC_SECRET (same value as in .env.local). 2) Run in Supabase SQL Editor.
-- 3) Check IMEI 490154203237518 in the app. 4) Remove with the DELETE at the bottom.
with u as (select id from auth.users where email = 'YOUR_EMAIL'),
d as (
  insert into devices (owner_id, imei_hash, imei_last4, brand, model)
  select id, encode(hmac('490154203237518', 'YOUR_IMEI_HMAC_SECRET', 'sha256'), 'hex'), '7518', 'Test', 'Test Phone' from u
  returning id
)
insert into lost_reports (device_id, reporter_id, incident_date, status)
select d.id, (select id from u), current_date, 'verified' from d;

-- cleanup: delete from devices where brand = 'Test' and model = 'Test Phone';
