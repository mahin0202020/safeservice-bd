import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Please log in first." }, { status: 401 });
  const { data, error } = await supabase.from("imei_search_logs").select("id, imei_last4, risk, created_at").order("created_at", { ascending: false }).limit(20);
  if (error) return NextResponse.json({ error: "Could not load history." }, { status: 500 });
  return NextResponse.json({ items: data });
}
