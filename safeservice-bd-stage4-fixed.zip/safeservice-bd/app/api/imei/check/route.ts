import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { hashImei, isValidImei, type Risk } from "@/lib/imei";

export const dynamic = "force-dynamic";
const HOURLY_LIMIT = 20;

export async function POST(req: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Please log in first." }, { status: 401 });

  let body: { imei?: unknown } = {};
  try { body = await req.json(); } catch { return NextResponse.json({ error: "Invalid request." }, { status: 400 }); }
  const imei = typeof body.imei === "string" ? body.imei.replace(/[\s-]/g, "") : "";
  if (!isValidImei(imei)) {
    return NextResponse.json({ error: "Enter a valid 15-digit IMEI. Dial *#06# on the phone to see it." }, { status: 400 });
  }

  try {
    const admin = createAdminClient();
    const since = new Date(Date.now() - 3600_000).toISOString();
    const { count } = await admin.from("imei_search_logs").select("id", { count: "exact", head: true }).eq("user_id", user.id).gte("created_at", since);
    if ((count ?? 0) >= HOURLY_LIMIT) {
      await admin.from("security_events").insert({ user_id: user.id, event_type: "imei_rate_limit", severity: "medium", details: { limit: HOURLY_LIMIT, window: "1h" } });
      return NextResponse.json({ error: `You reached ${HOURLY_LIMIT} checks in one hour. Try again later.` }, { status: 429 });
    }

    const hash = hashImei(imei);
    const { data, error } = await admin.from("lost_reports").select("status, devices!inner(imei_hash)").eq("devices.imei_hash", hash);
    if (error) throw error;
    const statuses = new Set(((data ?? []) as { status: string }[]).map((r) => r.status));
    const risk: Risk = statuses.has("verified") ? "reported" : statuses.has("under_review") ? "manual_review" : statuses.has("pending") ? "potential_risk" : "no_match";

    const last4 = imei.slice(-4);
    await admin.from("imei_search_logs").insert({ user_id: user.id, imei_hash: hash, imei_last4: last4, risk });
    return NextResponse.json({ risk, last4 });
  } catch (e) {
    const m = e instanceof Error ? e.message : "";
    console.error("imei check failed:", m);
    const msg = m === "IMEI_SECRET_MISSING" ? "Server is missing IMEI_HMAC_SECRET." : m === "ENV_MISSING" ? "Server is missing Supabase keys." : "The check failed. Try again.";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
