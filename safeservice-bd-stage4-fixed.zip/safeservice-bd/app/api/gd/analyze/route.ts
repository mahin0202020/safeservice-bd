import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { isValidImei } from "@/lib/imei";

export const dynamic = "force-dynamic";
// Keep below Vercel's ~4.5 MB serverless request-body limit.
const MAX_BYTES = 4 * 1024 * 1024;

export async function POST(req: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Please log in first." }, { status: 401 });

  const base = process.env.AI_SERVICE_URL;
  if (!base) return NextResponse.json({ error: "The AI service is not configured (AI_SERVICE_URL is empty)." }, { status: 503 });

  const form = await req.formData().catch(() => null);
  const file = form?.get("file");
  if (!(file instanceof File)) return NextResponse.json({ error: "Choose a PDF file." }, { status: 400 });
  if (file.size === 0 || file.size > MAX_BYTES) {
    return NextResponse.json({ error: "The PDF must be smaller than 4 MB because of the hosting upload limit." }, { status: 413 });
  }
  const bytes = new Uint8Array(await file.arrayBuffer());
  if (String.fromCharCode(...bytes.slice(0, 4)) !== "%PDF") return NextResponse.json({ error: "Only PDF files are supported. Offline GD photos/scans are not supported yet." }, { status: 400 });

  const imei = String(form?.get("expected_imei") ?? "").replace(/[\s-]/g, "");
  if (imei && !isValidImei(imei)) return NextResponse.json({ error: "The IMEI you entered is not valid." }, { status: 400 });

  const out = new FormData();
  out.append("file", new Blob([bytes], { type: "application/pdf" }), "gd.pdf");
  if (imei) out.append("expected_imei", imei);
  try {
    const res = await fetch(`${base.replace(/\/$/, "")}/analyze`, {
      method: "POST", body: out, headers: process.env.AI_SERVICE_KEY ? { "x-api-key": process.env.AI_SERVICE_KEY } : {},
      signal: AbortSignal.timeout(60_000),
    });
    const raw = await res.text();
    let payload: unknown;
    try {
      payload = JSON.parse(raw);
    } catch {
      return NextResponse.json(
        { error: "The screening service returned an invalid response. Please try again or contact the administrator." },
        { status: 502 },
      );
    }
    if (!res.ok) {
      const detail =
        typeof payload === "object" && payload !== null && "detail" in payload
          ? String((payload as { detail: unknown }).detail)
          : "The screening service rejected the file.";
      return NextResponse.json({ error: detail }, { status: 502 });
    }
    return NextResponse.json(payload); // The PDF is processed in memory; this route does not save it.
  } catch {
    return NextResponse.json({ error: "Could not reach the AI service. Is it running?" }, { status: 502 });
  }
}
