import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient, hasSupabaseEnv } from "@/lib/supabase/server";
import SidebarNav from "@/components/SidebarNav";
import SignOutButton from "@/components/SignOutButton";

export const dynamic = "force-dynamic";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  if (!hasSupabaseEnv()) {
    return <main className="mx-auto max-w-xl px-5 py-16"><p role="alert" className="rounded-md bg-caution-tint p-4 text-caution">Supabase keys are not set. Follow README step 4, then restart the server.</p></main>;
  }
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  return (
    <div className="min-h-screen md:flex">
      <aside className="border-b border-navy/10 bg-white p-4 md:min-h-screen md:w-60 md:border-b-0 md:border-r">
        <div className="mb-3 flex items-center justify-between md:mb-6">
          <Link href="/" className="text-lg font-bold text-navy">SafeService BD</Link>
          <div className="md:hidden"><SignOutButton /></div>
        </div>
        <SidebarNav />
        <div className="mt-8 hidden md:block"><SignOutButton /></div>
      </aside>
      <main className="flex-1 px-5 py-8 md:px-10">{children}</main>
    </div>
  );
}
