import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export default async function Dashboard() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const [{ data: profile }, { data: roles }, searches, reports] = await Promise.all([
    supabase.from("profiles").select("full_name").eq("id", user!.id).maybeSingle(),
    supabase.from("user_roles").select("role").eq("user_id", user!.id),
    supabase.from("imei_search_logs").select("id", { count: "exact", head: true }),
    supabase.from("lost_reports").select("id", { count: "exact", head: true }),
  ]);
  const cards = [["IMEI checks you made", searches.count ?? 0], ["Lost-phone reports you filed", reports.count ?? 0]] as const;
  return (
    <div className="max-w-3xl">
      <h1 className="text-2xl font-bold text-navy">Welcome{profile?.full_name ? `, ${profile.full_name}` : ""}</h1>
      <p className="mt-1 text-sm text-ink/70">{user!.email} · role: {roles?.map((r) => r.role).join(", ") || "user"}</p>
      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        {cards.map(([label, n]) => (
          <div key={label} className="rounded-lg border border-navy/15 bg-white p-5"><p className="text-3xl font-bold text-navy">{n}</p><p className="mt-1 text-sm text-ink/70">{label}</p></div>
        ))}
      </div>
      <Link href="/dashboard/imei" className="btn-primary mt-8">Check a phone’s IMEI</Link>
    </div>
  );
}
