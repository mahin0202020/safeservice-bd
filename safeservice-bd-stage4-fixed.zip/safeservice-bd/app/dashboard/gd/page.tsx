import GdScreener from "@/components/GdScreener";

export default function GdPage() {
  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-bold text-navy">GD document screening</h1>
      <p className="mt-1 text-sm text-ink/70">Supports <strong>online GD PDFs</strong> printed from gd.police.gov.bd. Offline (paper) GD is not supported yet and will be added later. Screening is rule-based and is not an official verification.</p>
      <GdScreener />
    </div>
  );
}
