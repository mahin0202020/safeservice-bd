import ImeiChecker from "@/components/ImeiChecker";

export default function ImeiPage() {
  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-bold text-navy">IMEI checker</h1>
      <p className="mt-1 text-sm text-ink/70">Checks only reports registered on SafeService BD. It is not connected to Bangladesh Police or BTRC.</p>
      <ImeiChecker />
    </div>
  );
}
