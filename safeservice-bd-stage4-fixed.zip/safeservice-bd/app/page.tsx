import Link from "next/link";

const results = [
  { name: "Reported lost or stolen", text: "A report on this platform matches the IMEI. Do not buy. Contact your nearest police station.", cls: "bg-alert-tint text-alert border-alert" },
  { name: "Potential risk", text: "A pending or partly matching report exists. Ask the seller for proof of ownership first.", cls: "bg-caution-tint text-caution border-caution" },
  { name: "Manual review required", text: "We could not decide automatically. An admin will look at it.", cls: "bg-navy-tint text-navy border-navy" },
  { name: "No matching report found", text: "Nothing registered here matches. This does not mean the phone is safe, only that nobody has reported it to us.", cls: "bg-verified-tint text-verified border-verified" },
];

export default function Home() {
  return (
    <div className="min-h-screen">
      <header className="mx-auto flex max-w-5xl items-center justify-between px-5 py-5">
        <span className="text-lg font-bold text-navy">SafeService BD</span>
        <nav className="flex items-center gap-3 text-sm">
          <Link href="/login" className="font-semibold text-navy">Log in</Link>
          <Link href="/register" className="btn-primary">Create account</Link>
        </nav>
      </header>
      <main className="mx-auto max-w-5xl px-5">
        <section className="py-14 sm:py-20">
          <h1 className="max-w-2xl text-4xl font-bold leading-tight text-navy sm:text-5xl">Check the phone before you pay for it.</h1>
          <p className="mt-5 max-w-xl text-lg text-ink/80">Enter a second-hand phone’s IMEI and see whether it has been reported lost or stolen on SafeService BD. Owners can register a lost phone with their GD so buyers get warned.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/register" className="btn-primary">Create a free account</Link>
            <Link href="/login" className="btn-ghost">I already have one</Link>
          </div>
        </section>
        <section className="pb-16" aria-labelledby="results-h">
          <h2 id="results-h" className="text-xl font-bold text-navy">What each result means</h2>
          <ul className="mt-5 grid gap-4 sm:grid-cols-2">
            {results.map((r) => (
              <li key={r.name} className={`rounded-lg border-l-4 p-4 ${r.cls}`}>
                <p className="font-bold">{r.name}</p>
                <p className="mt-1 text-sm text-ink/85">{r.text}</p>
              </li>
            ))}
          </ul>
          <p className="mt-6 max-w-2xl text-sm text-ink/70">SafeService BD is not connected to Bangladesh Police, BTRC or any official IMEI database. Results come only from reports registered here. Owner identity is never shown to buyers.</p>
        </section>
      </main>
    </div>
  );
}
