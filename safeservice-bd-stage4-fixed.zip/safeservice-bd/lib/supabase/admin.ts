import { createClient } from "@supabase/supabase-js";

/** Service-role client. Import only from server code (route handlers, server actions). */
export function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("ENV_MISSING");
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}
