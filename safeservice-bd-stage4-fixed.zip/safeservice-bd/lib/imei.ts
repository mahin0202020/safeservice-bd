import { createHmac } from "crypto";

export type Risk = "reported" | "potential_risk" | "no_match" | "manual_review";

/** 15 digits and a valid Luhn check digit. */
export function isValidImei(v: string): boolean {
  if (!/^\d{15}$/.test(v)) return false;
  let sum = 0;
  for (let i = 0; i < 15; i++) {
    let d = Number(v[i]);
    if (i % 2 === 1) { d *= 2; if (d > 9) d -= 9; }
    sum += d;
  }
  return sum % 10 === 0;
}

/** HMAC-SHA256 of the IMEI. Server only: the secret must never reach the browser. */
export function hashImei(imei: string): string {
  const secret = process.env.IMEI_HMAC_SECRET;
  if (!secret || secret.length < 16) throw new Error("IMEI_SECRET_MISSING");
  return createHmac("sha256", secret).update(imei).digest("hex");
}

export const RISK_UI: Record<Risk, { label: string; text: string; cls: string }> = {
  reported: { label: "Reported lost or stolen", text: "A verified report on this platform matches this IMEI. Do not buy. Contact your nearest police station.", cls: "border-alert bg-alert-tint text-alert" },
  potential_risk: { label: "Potential risk", text: "A report that is not yet verified matches this IMEI. Ask the seller for proof of ownership before paying.", cls: "border-caution bg-caution-tint text-caution" },
  manual_review: { label: "Manual review required", text: "A matching report is under admin review, so we cannot decide automatically. Wait for the review or do not buy.", cls: "border-navy bg-navy-tint text-navy" },
  no_match: { label: "No matching report found", text: "No report registered here matches this IMEI. This does not mean the phone is safe. It only means nobody has reported it to SafeService BD.", cls: "border-verified bg-verified-tint text-verified" },
};
