"""Rule-based screening of Bangladesh *online* GD PDFs (printed from gd.police.gov.bd).

Built from ONE authentic sample, so it is a template/consistency check, not a trained model.
It never says a document is genuine. Output is always reviewed by an admin.
"""
from __future__ import annotations
import re
from datetime import datetime, timedelta
from typing import Any
import numpy as np
import pymupdf as fitz

BN = str.maketrans("০১২৩৪৫৬৭৮৯", "0123456789")
EXPECTED_FONTS = ("nirmalaui", "timesnewroman", "kalpurush", "arial")
KNOWN_EDITORS = ("acrobat", "ilovepdf", "smallpdf", "sejda", "pdfescape", "foxit", "nitro", "pdf-xchange",
                 "canva", "photoshop", "illustrator", "wps", "microsoft", "word", "libreoffice", "pdfelement", "pymupdf", "reportlab", "fpdf")


def _f(level: str, code: str, message: str, weight: float = 0.0, **extra: Any) -> dict:
    return {"level": level, "code": code, "message": message, "weight": weight, **extra}


def _luhn(v: str) -> bool:
    s = 0
    for i, ch in enumerate(v):
        d = int(ch)
        if i % 2 == 1:
            d = d * 2 - 9 if d * 2 > 9 else d * 2
        s += d
    return s % 10 == 0


def _pdf_date(s: str | None) -> datetime | None:
    m = re.match(r"D:(\d{14})", s or "")
    return datetime.strptime(m.group(1), "%Y%m%d%H%M%S") if m else None


def _decode_qr(doc: fitz.Document) -> str | None:
    import cv2
    det = cv2.QRCodeDetector()
    for page in doc:
        for img in page.get_images(full=True):
            if img[2] > 800 or img[3] > 800 or img[2] < 60:
                continue
            try:
                pm = fitz.Pixmap(doc, img[0])
                if pm.n > 3:
                    pm = fitz.Pixmap(fitz.csRGB, pm)
                a = np.frombuffer(pm.samples, np.uint8).reshape(pm.h, pm.w, pm.n)
                a = cv2.copyMakeBorder(a, 40, 40, 40, 40, cv2.BORDER_CONSTANT, value=(255, 255, 255))
                a = cv2.resize(a, None, fx=3, fy=3, interpolation=cv2.INTER_NEAREST)
                val, _, _ = det.detectAndDecode(a)
                if val:
                    return val
            except Exception:
                continue
    return None


def analyze(pdf: bytes, expected_imei: str | None = None) -> dict:
    out = {"result": "unsupported", "format_match_score": 0.0, "tamper_score": 0.0, "findings": [], "extracted": {},
           "needs_admin_review": True, "model_version": "rules-0.1", "supported": "Online GD PDF printed from gd.police.gov.bd. Offline/paper GD is not supported yet."}
    F: list[dict] = out["findings"]
    if not pdf.startswith(b"%PDF"):
        F.append(_f("bad", "not_pdf", "The file is not a PDF. Image/OCR screening is planned but not built yet."))
        return out
    try:
        doc = fitz.open(stream=pdf, filetype="pdf")
    except Exception:
        F.append(_f("bad", "unreadable", "The PDF could not be opened."))
        return out

    text = "\n".join(p.get_text() for p in doc)
    norm = text.translate(BN)
    flat = norm.replace(" ", "")
    if len(norm.strip()) < 80:
        F.append(_f("bad", "no_text", "No text layer. This looks like a scan or photo (offline GD), which is not supported yet."))
        return out

    # ---- format anchors (what a real online GD print contains) ----
    ex = out["extracted"]
    anchors = 0
    total = 6
    has_url = "gd.police.gov.bd/LostFound" in flat
    anchors += has_url
    F.append(_f("ok" if has_url else "warn", "footer_url", "Footer shows a gd.police.gov.bd address." if has_url else "Footer gd.police.gov.bd address not found."))
    m = re.search(r"\b([A-Z]{3,6}\d{1,4})\b", norm)
    ex["tracking_no"] = m.group(1) if m else None
    anchors += bool(m)
    F.append(_f("ok" if m else "warn", "tracking_no", "GD tracking number found." if m else "GD tracking number not found."))
    m = re.search(r"জি\s*ডি\s*নং\s*:\s*(\d{1,8})", norm)
    ex["gd_no"] = m.group(1) if m else None
    anchors += bool(m)
    F.append(_f("ok" if m else "warn", "gd_no", "GD number found." if m else "GD number not found."))
    m = re.search(r"(\d{2})/(\d{2})/(\d{4})", norm)
    gd_date = None
    if m:
        try:
            gd_date = datetime(int(m.group(3)), int(m.group(2)), int(m.group(1)))
        except ValueError:
            pass
    ex["gd_date"] = gd_date.date().isoformat() if gd_date else None
    anchors += bool(gd_date)
    F.append(_f("ok" if gd_date else "warn", "gd_date", "GD date found." if gd_date else "A valid GD date was not found."))
    qr = _decode_qr(doc)
    ex["qr_url"] = qr
    qr_ok = bool(qr and re.match(r"https://gd\.police\.gov\.bd/", qr))
    anchors += qr_ok
    if qr is None:
        F.append(_f("warn", "qr", "QR code could not be read."))
    elif qr_ok:
        F.append(_f("ok", "qr", "QR code points to gd.police.gov.bd. This is a consistency check only; nothing was verified with the police."))
    else:
        F.append(_f("bad", "qr_host", "QR code points somewhere other than gd.police.gov.bd.", 0.5))
    hdr = re.search(r"(\d{1,2})/(\d{1,2})/(\d{2}), (\d{1,2}):(\d{2}) (AM|PM)", norm)
    anchors += bool(hdr)
    F.append(_f("ok" if hdr else "warn", "print_header", "Browser print header found." if hdr else "Browser print header (date/time) not found."))
    out["format_match_score"] = round(anchors / total, 2)

    if not has_url and not ex["tracking_no"]:
        F.append(_f("bad", "not_online_gd", "Does not look like an online GD print. Treated as unsupported."))
        return out

    # ---- tamper signals ----
    meta = doc.metadata or {}
    prod, creator = (meta.get("producer") or ""), (meta.get("creator") or "")
    ex["producer"], ex["creator"] = prod, creator
    pl = (prod + " " + creator).lower()
    if "skia/pdf" in pl and "chrome" in pl:
        F.append(_f("ok", "producer", "Created by a Chromium browser print, like the reference sample."))
    elif any(k in pl for k in KNOWN_EDITORS):
        F.append(_f("bad", "editor", f"PDF was produced/edited with another tool ({prod or creator}).", 0.5))
    else:
        F.append(_f("warn", "producer_other", f"Not the usual Chrome print ({prod or creator or 'unknown'}). A genuine GD printed from another browser/phone can look like this.", 0.2))
    c, mo = _pdf_date(meta.get("creationDate")), _pdf_date(meta.get("modDate"))
    if c and mo and abs((mo - c).total_seconds()) > 2:
        F.append(_f("bad", "modified", "Modified date differs from creation date.", 0.3))
    if pdf.count(b"%%EOF") > 1:
        F.append(_f("bad", "incremental", "PDF contains incremental updates (it was saved again after creation).", 0.4))
    fonts = {re.sub(r"^[A-Z]{6}\+", "", f[3]).lower().replace("-", "").replace(" ", "") for p in doc for f in p.get_fonts()}
    odd = sorted(f for f in fonts if not any(f.startswith(e) for e in EXPECTED_FONTS))
    if odd:
        generic = any(f.startswith(("helvetica", "courier", "symbol", "zapf", "timesroman", "times-roman")) for f in odd)
        F.append(_f("bad" if generic else "warn", "fonts_edit" if generic else "fonts",
                    f"Unexpected font(s) not in the reference sample: {', '.join(odd)}." + (" Standard editor fonts usually mean text was added after creation." if generic else ""), 0.4))
    regions = []
    for pno, page in enumerate(doc):
        words = page.get_text("words")
        for d in page.get_drawings():
            fill = d.get("fill")
            if fill and all(v > 0.97 for v in fill) and d["rect"].width > 8 and d["rect"].height > 5:
                if any(d["rect"].intersects(fitz.Rect(w[:4])) for w in words):
                    regions.append({"page": pno + 1, "bbox": [round(v, 1) for v in d["rect"]]})
    if regions:
        F.append(_f("bad", "cover_boxes", f"{len(regions)} white box(es) drawn over text, a common cover-up edit.", 0.4, regions=regions))
    if hdr and c:
        try:
            hd = datetime(2000 + int(hdr.group(3)), int(hdr.group(1)), int(hdr.group(2)))
            if abs((hd.date() - c.date()).days) > 1:
                F.append(_f("bad", "header_date", "Browser print date does not match the PDF creation date.", 0.25))
        except ValueError:
            pass
    if gd_date and c and gd_date.date() > (c + timedelta(days=1)).date():
        F.append(_f("bad", "future_date", "GD date is later than the date this PDF was created.", 0.5))

    # ---- IMEI cross-check ----
    imeis = [i for i in re.findall(r"(?<!\d)\d{15}(?!\d)", flat) if _luhn(i)]
    ex["imei_in_gd"] = imeis[0] if imeis else None
    if expected_imei:
        if not imeis:
            F.append(_f("warn", "imei_absent", "No IMEI found in this GD (a SIM/document GD has none). Cannot match it to the reported phone.", 0.15))
        elif expected_imei in imeis:
            F.append(_f("ok", "imei_match", "IMEI in the GD matches the IMEI you entered."))
        else:
            F.append(_f("bad", "imei_mismatch", "IMEI in the GD does NOT match the IMEI you entered.", 0.5))

    out["tamper_score"] = round(min(1.0, sum(f["weight"] for f in F)), 2)
    strong = any(f["code"] in {"editor", "incremental", "cover_boxes", "fonts_edit", "qr_host", "future_date", "imei_mismatch"} for f in F)
    if strong or out["tamper_score"] >= 0.5:
        out["result"] = "possible_tampering"
    elif out["tamper_score"] >= 0.2 or out["format_match_score"] < 1.0:
        out["result"] = "uncertain"
    else:
        out["result"] = "format_recognized"
    return out
