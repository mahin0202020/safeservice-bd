import os
from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile
from app.screening import analyze

app = FastAPI(title="SafeService BD AI service", version="0.1.0")
MAX_BYTES = 10 * 1024 * 1024


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/analyze")
async def analyze_gd(file: UploadFile = File(...), expected_imei: str | None = Form(None), x_api_key: str | None = Header(None)):
    key = os.environ.get("AI_SERVICE_KEY")
    if key and x_api_key != key:
        raise HTTPException(status_code=401, detail="Invalid API key")
    data = await file.read()
    if len(data) > MAX_BYTES:
        raise HTTPException(status_code=413, detail="File too large (max 10 MB)")
    return analyze(data, expected_imei.strip() if expected_imei else None)
