# Training (future work)
Plan: extract the same signals `app/screening.py` uses (metadata, fonts, drawings, date consistency) plus image features
(error-level analysis on rendered pages) as a feature vector; train scikit-learn RandomForest/Logistic Regression
on authentic vs tampered PDFs; evaluate with stratified cross-validation; report precision/recall for the tampered class.
