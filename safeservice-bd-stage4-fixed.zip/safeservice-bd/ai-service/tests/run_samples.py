"""Usage: python tests/run_samples.py path/to/authentic_online_gd.pdf
Makes tampered copies of the sample and prints the screening result for each."""
import sys, io, json
import pymupdf as fitz
sys.path.insert(0, ".")
from app.screening import analyze

src = sys.argv[1]
raw = open(src, "rb").read()

def show(name, data):
    r = analyze(data)
    print(f"{name:34s} -> {r['result']:20s} format={r['format_match_score']} tamper={r['tamper_score']}  [{', '.join(f['code'] for f in r['findings'] if f['level']=='bad')}]")
show("authentic sample", raw)

d = fitz.open(src); d[0].insert_text((300, 400), "edited", fontsize=12); b = d.tobytes(); show("text added (re-saved)", b)
d = fitz.open(src); w = [x for x in d[0].get_text("words") if x[4].startswith("GMMC")][0]
d[0].draw_rect(fitz.Rect(w[:4]), color=(1, 1, 1), fill=(1, 1, 1)); show("white box over tracking no.", d.tobytes())
import shutil; shutil.copy(src, "/tmp/incr.pdf"); d = fitz.open("/tmp/incr.pdf"); d[0].insert_text((300, 400), "x", fontsize=8); d.saveIncr(); show("incremental save", open("/tmp/incr.pdf", "rb").read())
d = fitz.open(src); d[0].insert_text((300, 400), "x", fontsize=8); buf = io.BytesIO(); d.save(buf, incremental=False); show("rebuilt by PyMuPDF", buf.getvalue())
show("not a pdf", b"hello")
