# Datasets (not committed: they contain personal data)
- `authentic/`: verified online GD PDFs. Redact NID, phone and address before adding.
- `tampered/`: controlled tampered copies you make yourself (change a date/number, white-box a field, re-save in an editor).
Train the scikit-learn classifier (`training/`) only after you have many of both. One sample is not enough.
