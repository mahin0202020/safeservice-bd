-- SafeService BD — Stage 1 schema. Run once in Supabase > SQL Editor.
create extension if not exists pgcrypto;

create type app_role as enum ('user','admin','super_admin');
create type report_status as enum ('pending','under_review','verified','rejected','recovered');
create type risk_level as enum ('reported','potential_risk','no_match','manual_review');
create type gd_result as enum ('format_recognized','possible_tampering','uncertain','unsupported');
create type transfer_status as enum ('pending','accepted','rejected','disputed','completed','cancelled');
create type recovery_status as enum ('open','in_progress','recovered','closed');
create type severity as enum ('low','medium','high');

create or replace function set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text, phone text,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table user_roles (
  user_id uuid not null references auth.users(id) on delete cascade,
  role app_role not null,
  primary key (user_id, role)
);
create table devices (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  imei_hash text not null,               -- HMAC-SHA256 of the IMEI, never the raw IMEI
  imei_last4 char(4),
  brand text not null, model text not null,
  created_at timestamptz not null default now(),
  unique (owner_id, imei_hash)
);
create table police_stations (
  id uuid primary key default gen_random_uuid(),
  name text not null, district text not null, address text, phone text,
  verified boolean not null default false, source text,
  created_at timestamptz not null default now()
);
create table lost_reports (
  id uuid primary key default gen_random_uuid(),
  device_id uuid not null references devices(id) on delete cascade,
  reporter_id uuid not null references auth.users(id) on delete cascade,
  incident_date date not null, incident_details text,
  gd_number text, gd_date date,
  police_station_id uuid references police_stations(id),
  status report_status not null default 'pending',
  reviewed_by uuid references auth.users(id), reviewed_at timestamptz, admin_notes text,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table gd_documents (
  id uuid primary key default gen_random_uuid(),
  report_id uuid not null references lost_reports(id) on delete cascade,
  uploader_id uuid not null references auth.users(id) on delete cascade,
  storage_path text not null, mime_type text not null, sha256 text,
  created_at timestamptz not null default now()
);
create table gd_analyses (
  id uuid primary key default gen_random_uuid(),
  document_id uuid not null references gd_documents(id) on delete cascade,
  result gd_result not null,
  confidence numeric(4,3) check (confidence between 0 and 1),
  extracted jsonb not null default '{}', findings jsonb not null default '[]',
  model_version text, needs_admin_review boolean not null default true,
  created_at timestamptz not null default now()
);
create table imei_search_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  imei_hash text not null, imei_last4 char(4), risk risk_level not null,
  created_at timestamptz not null default now()
);
create table ownership_transfers (
  id uuid primary key default gen_random_uuid(),
  device_id uuid not null references devices(id) on delete cascade,
  seller_id uuid not null references auth.users(id), buyer_id uuid not null references auth.users(id),
  status transfer_status not null default 'pending',
  seller_consent boolean not null default false, buyer_consent boolean not null default false,
  dispute_note text,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  check (seller_id <> buyer_id)
);
create table recovery_cases (
  id uuid primary key default gen_random_uuid(),
  report_id uuid not null references lost_reports(id) on delete cascade,
  status recovery_status not null default 'open',
  progress_note text, admin_notes text,   -- admin_notes: owners read cases only through the server API, which omits this column
  police_station_id uuid references police_stations(id),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table security_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  event_type text not null, severity severity not null default 'low', details jsonb not null default '{}',
  created_at timestamptz not null default now()
);
create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null, body text, read boolean not null default false,
  created_at timestamptz not null default now()
);
create table audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references auth.users(id) on delete set null,
  action text not null, entity text not null, entity_id uuid, details jsonb not null default '{}',
  created_at timestamptz not null default now()
);

create index on devices (imei_hash);
create index on lost_reports (reporter_id);
create index on lost_reports (device_id);
create index on lost_reports (status);
create index on gd_documents (report_id);
create index on gd_analyses (document_id);
create index on imei_search_logs (user_id, created_at desc);
create index on imei_search_logs (imei_hash);
create index on ownership_transfers (seller_id);
create index on ownership_transfers (buyer_id);
create index on recovery_cases (report_id);
create index on security_events (created_at desc);
create index on notifications (user_id, read);
create index on audit_logs (created_at desc);
create index on police_stations (district);

create trigger t_profiles before update on profiles for each row execute function set_updated_at();
create trigger t_reports before update on lost_reports for each row execute function set_updated_at();
create trigger t_transfers before update on ownership_transfers for each row execute function set_updated_at();
create trigger t_recovery before update on recovery_cases for each row execute function set_updated_at();

-- Role helpers (security definer so policies can read user_roles safely)
create or replace function is_admin() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from user_roles where user_id = auth.uid() and role in ('admin','super_admin'))
$$;

-- Every new auth user gets a profile and the 'user' role
create or replace function handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, full_name) values (new.id, new.raw_user_meta_data->>'full_name');
  insert into user_roles (user_id, role) values (new.id, 'user');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

-- Row Level Security
alter table profiles enable row level security;
alter table user_roles enable row level security;
alter table devices enable row level security;
alter table police_stations enable row level security;
alter table lost_reports enable row level security;
alter table gd_documents enable row level security;
alter table gd_analyses enable row level security;
alter table imei_search_logs enable row level security;
alter table ownership_transfers enable row level security;
alter table recovery_cases enable row level security;
alter table security_events enable row level security;
alter table notifications enable row level security;
alter table audit_logs enable row level security;

create policy profiles_read on profiles for select using (id = auth.uid() or is_admin());
create policy profiles_update on profiles for update using (id = auth.uid()) with check (id = auth.uid());
create policy roles_read on user_roles for select using (user_id = auth.uid() or is_admin());  -- writes: service role only
create policy devices_read on devices for select using (owner_id = auth.uid() or is_admin());
create policy devices_insert on devices for insert with check (owner_id = auth.uid());
create policy stations_read on police_stations for select using (auth.uid() is not null and (verified or is_admin()));
create policy stations_admin on police_stations for all using (is_admin()) with check (is_admin());
create policy reports_read on lost_reports for select using (reporter_id = auth.uid() or is_admin());
create policy reports_insert on lost_reports for insert with check (reporter_id = auth.uid() and status = 'pending');
create policy reports_admin_update on lost_reports for update using (is_admin()) with check (is_admin());
create policy gddocs_read on gd_documents for select using (uploader_id = auth.uid() or is_admin());
create policy gddocs_insert on gd_documents for insert with check (uploader_id = auth.uid());
create policy gdan_read on gd_analyses for select using (
  is_admin() or exists (select 1 from gd_documents d where d.id = document_id and d.uploader_id = auth.uid()));
create policy searchlogs_read on imei_search_logs for select using (user_id = auth.uid() or is_admin());
create policy transfers_read on ownership_transfers for select using (seller_id = auth.uid() or buyer_id = auth.uid() or is_admin());
create policy transfers_insert on ownership_transfers for insert with check (seller_id = auth.uid());
create policy recovery_admin on recovery_cases for all using (is_admin()) with check (is_admin());
create policy security_admin on security_events for select using (is_admin());
create policy notif_read on notifications for select using (user_id = auth.uid());
create policy notif_update on notifications for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy audit_admin on audit_logs for select using (is_admin());

-- Private storage buckets (no public access; the server uses the service role)
insert into storage.buckets (id, name, public) values ('gd-documents','gd-documents', false), ('ownership-evidence','ownership-evidence', false)
on conflict (id) do nothing;
