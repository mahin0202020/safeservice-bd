-- After you register in the app, run this once in Supabase SQL Editor with YOUR email.
insert into user_roles (user_id, role)
select id, 'super_admin' from auth.users where email = 'your-email@example.com'
on conflict do nothing;
