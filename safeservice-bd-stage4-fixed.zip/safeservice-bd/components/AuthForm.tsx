"use client";
import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";

type Mode = "login" | "register" | "forgot" | "reset";
const copy: Record<Mode, { title: string; button: string }> = {
  login: { title: "Log in", button: "Log in" },
  register: { title: "Create your account", button: "Create account" },
  forgot: { title: "Reset your password", button: "Send reset link" },
  reset: { title: "Choose a new password", button: "Save new password" },
};

export default function AuthForm({ mode }: { mode: Mode }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null); setNotice(null); setBusy(true);
    const f = new FormData(e.currentTarget);
    const email = String(f.get("email") ?? "").trim();
    const password = String(f.get("password") ?? "");
    const fullName = String(f.get("full_name") ?? "").trim();
    try {
      const supabase = createClient();
      const origin = window.location.origin;
      if (mode === "register") {
        if (password.length < 8) throw new Error("Password must be at least 8 characters.");
        const { error } = await supabase.auth.signUp({ email, password, options: { data: { full_name: fullName }, emailRedirectTo: `${origin}/auth/callback` } });
        if (error) throw error;
        setNotice("Account created. Open the verification link we emailed you, then log in.");
      } else if (mode === "login") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        router.push("/dashboard"); router.refresh();
      } else if (mode === "forgot") {
        const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${origin}/auth/callback?next=/reset-password` });
        if (error) throw error;
        setNotice("If that email has an account, a reset link is on its way.");
      } else {
        if (password.length < 8) throw new Error("Password must be at least 8 characters.");
        const { error } = await supabase.auth.updateUser({ password });
        if (error) throw error;
        router.push("/dashboard"); router.refresh();
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Something went wrong.";
      setError(msg === "ENV_MISSING" ? "Supabase keys are not set. Add them to .env.local (see README, step 4) and restart." : msg);
    } finally { setBusy(false); }
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-5 py-10">
      <Link href="/" className="mb-8 text-lg font-bold text-navy">SafeService BD</Link>
      <h1 className="mb-6 text-2xl font-bold text-navy">{copy[mode].title}</h1>
      <form onSubmit={onSubmit} className="space-y-4" noValidate={false}>
        {mode === "register" && (
          <label className="block text-sm font-medium">Full name
            <input name="full_name" required autoComplete="name" className="field mt-1" />
          </label>
        )}
        {mode !== "reset" && (
          <label className="block text-sm font-medium">Email
            <input name="email" type="email" required autoComplete="email" className="field mt-1" />
          </label>
        )}
        {mode !== "forgot" && (
          <label className="block text-sm font-medium">{mode === "reset" ? "New password" : "Password"}
            <input name="password" type="password" required minLength={8} autoComplete={mode === "login" ? "current-password" : "new-password"} className="field mt-1" />
          </label>
        )}
        {error && <p role="alert" className="rounded-md bg-alert-tint px-3 py-2 text-sm text-alert">{error}</p>}
        {notice && <p role="status" className="rounded-md bg-verified-tint px-3 py-2 text-sm text-verified">{notice}</p>}
        <button type="submit" disabled={busy} className="btn-primary w-full">{busy ? "Please wait…" : copy[mode].button}</button>
      </form>
      <div className="mt-6 space-y-2 text-sm">
        {mode === "login" && (<>
          <p><Link href="/forgot-password" className="text-navy underline">Forgot your password?</Link></p>
          <p>New here? <Link href="/register" className="text-navy underline">Create an account</Link></p>
        </>)}
        {mode === "register" && <p>Already registered? <Link href="/login" className="text-navy underline">Log in</Link></p>}
        {mode === "forgot" && <p><Link href="/login" className="text-navy underline">Back to log in</Link></p>}
      </div>
    </main>
  );
}
