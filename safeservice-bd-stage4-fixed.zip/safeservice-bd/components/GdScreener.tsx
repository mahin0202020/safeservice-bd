"use client";
import { useState, type FormEvent } from "react";

type Finding = { level: "ok" | "warn" | "bad"; code: string; message: string };
type Analysis = { result: "format_recognized" | "possible_tampering" | "uncertain" | "unsupported"; format_match_score: number; tamper_score: number; findings: Finding[]; extracted: Record<string, string | null> };

const R = {
  format_recognized: { label: "Online GD format recognized", cls: "border-verified bg-verified-tint text-verified", note: "The layout and file structure match the reference. This does NOT prove the GD is genuine. An admin still has to review it." },
  possible_tampering: { label: "Possible tampering detected", cls: "border-alert bg-alert-tint text-alert", note: "One or more signs of editing were found. Send to admin review. This is not proof of fraud." },
  uncertain: { label: "Uncertain: manual review required", cls: "border-caution bg-caution-tint text-caution", note: "Some expected details are missing or unusual. An admin must review it." },
  unsupported: { label: "Unsupported document format", cls: "border-navy bg-navy-tint text-navy", note: "Only online GD PDFs printed from gd.police.gov.bd are supported for now. Offline GD support is planned." },
} as const;
const ICON = { ok: "✓", warn: "!", bad: "✕" } as const;
const TONE = { ok: "text-verified", warn: "text-caution", bad: "text-alert" } as const;

export default function GdScreener() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [res, setRes] = useState<Analysis | null>(null);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null); setRes(null); setBusy(true);
    try {
      const form = new FormData(e.currentTarget);
      const file = form.get("file");
      // Vercel Serverless Functions have an approximately 4.5 MB request-body limit.
      if (file instanceof File && file.size > 4 * 1024 * 1024) {
        throw new Error("PDF must be smaller than 4 MB. Please compress the PDF and try again.");
      }

      const r = await fetch("/api/gd/analyze", { method: "POST", body: form });
      const raw = await r.text();
      let data: any;
      try {
        data = JSON.parse(raw);
      } catch {
        throw new Error(
          r.status === 413
            ? "The PDF is too large for the hosting upload limit. Please use a PDF smaller than 4 MB."
            : "The server returned an unexpected response. Please try again."
        );
      }
      if (!r.ok) throw new Error(data.error ?? "Screening failed.");
      setRes(data);
    } catch (err) { setError(err instanceof Error ? err.message : "Screening failed."); }
    finally { setBusy(false); }
  }

  return (
    <div className="mt-6">
      <form onSubmit={onSubmit} className="space-y-4">
        <label className="block text-sm font-medium">Online GD (PDF)
          <input name="file" type="file" accept="application/pdf,.pdf" required className="field mt-1" />
        </label>
        <label className="block text-sm font-medium">IMEI of the reported phone (optional, to cross-check)
          <input name="expected_imei" inputMode="numeric" maxLength={20} className="field mt-1" placeholder="15 digits" />
        </label>
        <button type="submit" disabled={busy} className="btn-primary">{busy ? "Screening…" : "Screen this GD"}</button>
      </form>
      <p className="mt-3 text-xs text-ink/60">The PDF is analysed and then discarded. It is not stored, because it contains NID, phone and address.</p>
      {error && <p role="alert" className="mt-4 rounded-md bg-alert-tint px-3 py-2 text-sm text-alert">{error}</p>}
      {res && (
        <section aria-live="polite" className="mt-6">
          <div className={`rounded-lg border-l-4 p-4 ${R[res.result].cls}`}>
            <p className="font-bold">{R[res.result].label}</p>
            <p className="mt-1 text-sm text-ink/85">{R[res.result].note}</p>
            <p className="mt-2 text-xs text-ink/70">Format match {Math.round(res.format_match_score * 100)}% · Tamper signals {Math.round(res.tamper_score * 100)}%</p>
          </div>
          <h2 className="mt-6 text-lg font-bold text-navy">What was checked</h2>
          <ul className="mt-2 divide-y divide-navy/10 rounded-lg border border-navy/15 bg-white">
            {res.findings.map((f) => (
              <li key={f.code} className="flex gap-3 px-4 py-2.5 text-sm"><span className={`w-4 font-bold ${TONE[f.level]}`} aria-label={f.level}>{ICON[f.level]}</span><span>{f.message}</span></li>
            ))}
          </ul>
          <p className="mt-4 text-sm text-ink/70">Found: GD no. {res.extracted.gd_no ?? "?"} · date {res.extracted.gd_date ?? "?"} · tracking {res.extracted.tracking_no ?? "?"}</p>
        </section>
      )}
    </div>
  );
}
