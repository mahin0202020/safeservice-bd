"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const live = [{ href: "/dashboard", label: "Overview" }, { href: "/dashboard/imei", label: "IMEI checker" }, { href: "/dashboard/gd", label: "GD screening" }];
const soon = [["Report a lost phone", "Stage 3"], ["Ownership transfer", "Stage 5"], ["Recovery tracking", "Stage 5"], ["Admin", "Stage 6"]];

export default function SidebarNav() {
  const path = usePathname();
  return (
    <nav aria-label="Main" className="flex gap-1 overflow-x-auto md:flex-col md:overflow-visible">
      {live.map((l) => (
        <Link key={l.href} href={l.href} aria-current={path === l.href ? "page" : undefined}
          className={`whitespace-nowrap rounded-md px-3 py-2 text-sm font-semibold ${path === l.href ? "bg-navy text-white" : "text-navy hover:bg-navy-tint"}`}>{l.label}</Link>
      ))}
      {soon.map(([n, s]) => (
        <span key={n} className="hidden whitespace-nowrap px-3 py-2 text-sm text-ink/45 md:block">{n} <span className="text-xs">({s})</span></span>
      ))}
    </nav>
  );
}
