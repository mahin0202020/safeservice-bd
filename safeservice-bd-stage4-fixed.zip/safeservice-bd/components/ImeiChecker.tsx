"use client";
import { useCallback, useEffect, useState, type FormEvent } from "react";
import { RISK_UI, isValidImei, type Risk } from "@/lib/imei";

type Item = { id: string; imei_last4: string; risk: Risk; created_at: string };

export default function ImeiChecker() {
  const [imei, setImei] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{ risk: Risk; last4: string } | null>(null);
  const [items, setItems] = useState<Item[]>([]);

  const loadHistory = useCallback(async () => {
    const res = await fetch("/api/imei/history");
    if (res.ok) setItems((await res.json()).items);
  }, []);
  useEffect(() => { loadHistory(); }, [loadHistory]);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null); setResult(null);
    const clean = imei.replace(/[\s-]/g, "");
    if (!isValidImei(clean)) { setError("Enter a valid 15-digit IMEI. Dial *#06# on the phone to see it."); return; }
    setBusy(true);
    try {
      const res = await fetch("/api/imei/check", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ imei: clean }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "The check failed.");
      setResult(data); loadHistory();
    } catch (err) { setError(err instanceof Error ? err.message : "The check failed."); }
    finally { setBusy(false); }
  }

  return (
    <div className="mt-6">
      <form onSubmit={onSubmit} className="flex flex-col gap-3 sm:flex-row">
        <label className="flex-1 text-sm font-medium">IMEI number
          <input value={imei} onChange={(e) => setImei(e.target.value)} inputMode="numeric" maxLength={20} placeholder="15 digits" className="field mt-1" />
        </label>
        <button type="submit" disabled={busy} className="btn-primary sm:mt-6">{busy ? "Checking…" : "Check IMEI"}</button>
      </form>
      {error && <p role="alert" className="mt-4 rounded-md bg-alert-tint px-3 py-2 text-sm text-alert">{error}</p>}
      {result && (
        <div role="status" className={`mt-4 rounded-lg border-l-4 p-4 ${RISK_UI[result.risk].cls}`}>
          <p className="font-bold">{RISK_UI[result.risk].label} <span className="font-normal">(IMEI ending {result.last4})</span></p>
          <p className="mt-1 text-sm text-ink/85">{RISK_UI[result.risk].text}</p>
        </div>
      )}
      <h2 className="mt-10 text-lg font-bold text-navy">Your recent checks</h2>
      {items.length === 0 ? <p className="mt-2 text-sm text-ink/60">No checks yet. Enter an IMEI above to start.</p> : (
        <ul className="mt-3 divide-y divide-navy/10 rounded-lg border border-navy/15 bg-white">
          {items.map((i) => (
            <li key={i.id} className="flex items-center justify-between gap-3 px-4 py-3 text-sm">
              <span>IMEI ending {i.imei_last4} · {RISK_UI[i.risk].label}</span>
              <time className="shrink-0 text-ink/60" dateTime={i.created_at}>{new Date(i.created_at).toLocaleString("en-GB")}</time>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
