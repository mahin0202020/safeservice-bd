# SafeService BD — Stage 1 (Foundation)

Built so far: Next.js 15 + TypeScript + Tailwind, Supabase auth (register, email verification, login, logout, forgot/reset password), role table, protected dashboard, and the full database schema with Row Level Security.
NOT built yet: IMEI checker, reports, GD AI service, ownership, recovery, admin panel (see docs/STAGES.md).

## 1. Install Node.js 20 or newer
Check with `node -v`.

## 2. Create a Supabase project
supabase.com > New project. Wait until it is ready.

## 3. Create the database
Supabase > SQL Editor > New query > paste all of `supabase/migrations/0001_schema.sql` > Run.

## 4. Environment variables
Copy `.env.example` to `.env.local`. Fill from Supabase > Project Settings > API:
- NEXT_PUBLIC_SUPABASE_URL = Project URL
- NEXT_PUBLIC_SUPABASE_ANON_KEY = anon public key
- SUPABASE_SERVICE_ROLE_KEY = service_role key (secret)
- IMEI_HMAC_SECRET = run `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
Leave AI_SERVICE_URL empty for now.

## 5. Supabase auth URLs
Authentication > URL Configuration: Site URL `http://localhost:3000`; add Redirect URL `http://localhost:3000/auth/callback`.

## 6. Run
```
npm install
npm run dev
```
Open http://localhost:3000, register, verify your email, log in.

## 7. Make yourself admin
Edit your email in `supabase/seed_admin.sql` and run it in the SQL Editor.

## 8. Deploy on Vercel
Push to GitHub > Vercel > Add New Project > import. Add the same environment variables (set NEXT_PUBLIC_APP_URL to your Vercel URL). After deploy, add your Vercel URL and `https://YOUR-APP.vercel.app/auth/callback` in Supabase URL Configuration.

## Stage 2 additions
- Dashboard sidebar, `/dashboard/imei` checker, `POST /api/imei/check`, `GET /api/imei/history`.
- Set a real `IMEI_HMAC_SECRET` (PowerShell, copies to clipboard without printing it): `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))" | clip` then paste into `.env.local` and Vercel. Do not change it once real reports exist.
- To see a red result before Stage 3 exists, use `docs/TEST_IMEI.sql`.

## Stage 4 (GD screening) — run the AI service locally
```
cd ai-service
python -m venv .venv
.venv\Scripts\activate          (Windows)   |   source .venv/bin/activate  (Mac/Linux)
pip install -r requirements.txt
uvicorn app.main:app --port 8000
```
Then set `AI_SERVICE_URL=http://localhost:8000` in `.env.local`, restart `npm run dev`, open Dashboard > GD screening.
Test the rules on your own sample: `python tests/run_samples.py path\to\online_gd.pdf`.
For production, deploy `ai-service` separately (Render/Railway/Fly) and put its URL in Vercel's `AI_SERVICE_URL`. The Vercel-facing upload route is limited to 4 MB because Vercel Serverless Functions have an approximately 4.5 MB request-body limit. Larger PDFs need a direct-to-AI-service upload design.
