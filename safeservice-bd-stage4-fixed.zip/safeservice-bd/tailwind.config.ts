import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        navy: { DEFAULT: "#0B2545", soft: "#13315C", tint: "#E8EEF7" },
        paper: "#F6F8FB",
        ink: "#16202E",
        verified: { DEFAULT: "#1F7A4D", tint: "#E3F3EA" },
        alert: { DEFAULT: "#B3261E", tint: "#FBE9E7" },
        caution: { DEFAULT: "#8A5A00", tint: "#FFF3D6" },
      },
      fontFamily: { sans: ["Segoe UI", "Noto Sans Bengali", "Helvetica Neue", "Arial", "sans-serif"] },
    },
  },
  plugins: [],
};
export default config;
